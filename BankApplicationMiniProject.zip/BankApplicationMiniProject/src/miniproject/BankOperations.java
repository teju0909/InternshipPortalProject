package miniproject;

import java.util.Scanner;

public class BankOperations {
	
	
	static int AccountBal = 0;
	
	public void ViewBalance() {
		System.out.println("Your Current Balance is:"+AccountBal);
		
	}


	public void creditMoney() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the amount which you want to Add");
		int CreditMon = sc.nextInt();
		AccountBal = AccountBal + CreditMon;
		System.out.println();
		System.out.println("Transaction Successful...");
	}


	public void withdrawMoney() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the amount which you want to Withdraw");
		int withDrawAmount = sc.nextInt();
		
		AccountBal = AccountBal - withDrawAmount;
		if(AccountBal<500) {
			System.out.println();
			System.out.println("Sorry.. You Can't Withdraw Money.."+"\n"+"Because Entered Amount Is Exceeded From Minimum Balance Limit (Min Bal Limit = 500 Rs)");
			AccountBal = AccountBal + withDrawAmount;
		}else {
			System.out.println("Withdraw Operation Successful..");
			System.out.println("Balance is :: "+AccountBal);		}
		
	}


	public void openAccount() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Opening Bank Amount..");
		int openAmnt = sc.nextInt();
		if(openAmnt<500) {
			System.out.println();
			System.out.println("You Can't Open Account With Less Than 500 Rupees");
		}else {
			AccountBal = AccountBal + openAmnt;
			System.out.println("Transaction Successful...");
			
		}
		
	}

}
